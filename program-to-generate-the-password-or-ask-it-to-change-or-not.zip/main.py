import random
import getpass
a = int(input("Enter the length of password you required"))
l = ['1','2','3','4','5','6','7','8','9''0','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','w','x','y','z','!','@','#','$','%','&']
otp = []
for i in range(a):
    a = random.choice(l)
    otp+=a
password = ''.join(otp)
print(password)
print('if you like the password print yes else no')
t = str(input())
if(t == 'yes'):
    print("Thanks to like it")
else:
    
    Password = getpass.getpass('Enter your password : ')
    a = len(Password)
    print('*'*a)
    print('You want to see your password')
    t = str(input('give your answer in Yes or No   '))
    if(t=='Yes' or t=='yes'):
        print(Password)

    
    
    
