d = int(input('Enter the common difference of n series: '))
a = int(input("Enter the number of series: "))
sum =0
for i in range(a):
    sum = sum + (1+i*d)
print(sum)
    