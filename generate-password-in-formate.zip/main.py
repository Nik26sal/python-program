import getpass

Password = getpass.getpass('Enter your password : ')
a = len(Password)
print('*'*a)
print('You want to see your password')
t = str(input('give your answer in Yes or No   '))
if(t=='Yes' or t=='yes'):
    print(Password)