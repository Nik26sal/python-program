import calendar

month = int(input("Enter the month number:  "))
year = int(input("Enter the year :  "))
cal =  calendar.TextCalendar()
print(cal.formatmonth(year, month))