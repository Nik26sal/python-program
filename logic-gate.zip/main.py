print('Choose the type of gate you want to solve')
print('''Enter _1 for AND
Enter _2 for OR
Enter _3 for NOT
Enter _4 for XOR''')
a = int(input())
print("1 for giving signal or 0 for not giving signal")
A = int(input())
B = int(input())
if (a == 1):
    if(A*B == 0):
        print("The Output is 0")
    else:
        print("The output is 1")
if (a == 2):
    if(A+B == 0):
        print("The Output is 0")
    else:
        print("The output is 1")
if (a == 3):
    if(A == 1):
        print("The Output is 0")
    else:
        print("The output is 1")
if (a == 4):
    if(A == B):
        print("The Output is 0")
    else:
        print("The output is 1")
print("Thank you to use it")        


