import random
capt = []
a = int(input('Enter the length of otp you want : '))
print("Your OTP is :")
for i in range (a):
    a = random.randint(0,9)
    print(a,end='')
print('\n')
a = int(input('Enter the length of captcha you want : '))
print('Your CAPTCHA is :')
for i in range (a):
    a = random.randint(65,90)
    b = random.randint(97,122)
    t = random.randint(1,2)
    if(t == 1):
        capt.append(chr(a))
    else:
        capt.append(chr(b))
captcha = ''.join(capt)
print(captcha)
    
    
    
