row =5
for i in range(row,0,-1):
    for j in range(1,row+1):
        if(j>=i):
            print('*',end='')
        else:
            print(" ",end='')
    print()
