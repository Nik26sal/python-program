def calculator():
    cal = input('Enter your expression : ')
    d = eval(cal)
    return d
 
print('You Want to do calculation  ')
print('yes for open or no')
s = str(input('Enter your opinion : '))
if(s=='yes'):
    d = calculator()
print(d)
