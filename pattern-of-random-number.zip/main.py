import random
row =5
for i in range(1,row+1):
    for j in range(i):
        a = random.randint(0,9)
        print(a,end='')
    print()